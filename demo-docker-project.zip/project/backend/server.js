const express = require("express");
const mysql = require("mysql2");
const app = express();

const db = mysql.createConnection({
  host: "db", // 'db' is the Docker service name for MySQL
  user: "root",
  password: "password",
  database: "demo_db",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
    process.exit(1);
  }
  console.log("Connected to MySQL database");

  // Ensure sample data exists
  const createTableQuery =
    "CREATE TABLE IF NOT EXISTS sample_table (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255))";
  db.query(createTableQuery, (err) => {
    if (err) console.error("Error creating table:", err);

    const insertQuery =
      "INSERT INTO sample_table (name) VALUES ('Alice'), ('Bob'), ('Charlie')";
    db.query(insertQuery, (err) => {
      if (err && err.code !== "ER_DUP_ENTRY")
        console.error("Error inserting sample data:", err);
    });
  });
});

// Root route
app.get("/", (req, res) => {
  res.send("Welcome to the Backend Service");
});

// Data route
app.get("/data", (req, res) => {
  const query = "SELECT * FROM sample_table";
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching data:", err);
      res.status(500).send("Error fetching data");
      return;
    }
    res.json(results);
  });
});

app.listen(5000, () => {
  console.log("Backend server is running on port 5000");
});

